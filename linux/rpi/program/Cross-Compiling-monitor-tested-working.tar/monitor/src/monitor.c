// Aplicaci�n para RPI con termometro
// 4D Systems
// This application communicates with an intelligent 4D Systems display, configured with ViSi-Genie.
// The display has a slider, a cool gauge, an LED digits and a string box.
// The program receives messages from the slider, which is cofigured to report a message when its status has changed.
// The values received from the slider are written to the LED digits using the function genieWriteObj().
// The coolgauge is written to using the function genieWriteObj(),
// and the string is updated using the function genieWriteStr().

#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>
#include <math.h>
#include <time.h>

#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <sys/stat.h>

#include <geniePi.h>  //the ViSi-Genie-RaspPi library
#include <monitorAM2320.h> //monitor for i2c AM2320 sensor library

//Alarm hit values
int alarmTemp = 0;
int alarmHum = 0;
struct senseMonitor mysense ;	 //declare a senseMonitor type structure


//This a thread for writing to the Thermometer0 and the Angularmeter0
//and to activate/disactivate the set alarm led
//This process repeats forever, running in parallel with the main.
static void *handleSenseAndMeters(void *data)
{
	//Sense values
	//float termoVal = 0;   //holds the value of the c
	//unsigned int humVal = 0;   //holds the value of the c

  for(;;)             //infinite loop
  {
	mysense = getsenseAM2320();
	//Update genieLEDS pilots
	if ((int) mysense.humidity >= alarmHum)
	{
		genieWriteObj(GENIE_OBJ_USER_LED, 0x01, 1);		//genieLED humidity is turned on
	}
	else
	{
	 	genieWriteObj(GENIE_OBJ_USER_LED, 0x01, 0);		//genieLED humidity is turned off
	}

	if ((int) mysense.temperature >= alarmTemp)
	{
		genieWriteObj(GENIE_OBJ_USER_LED, 0x00, 1);	    //genieLED temperature is turned on
	}
	else
	{
	 	genieWriteObj(GENIE_OBJ_USER_LED, 0x00, 0);	    //genieLED temperature is turned off
	}

	//write to Thermometer0
    genieWriteObj(GENIE_OBJ_THERMOMETER, 0x00, mysense.temperature);
    //write to Angularmeter0
    genieWriteObj(GENIE_OBJ_ANGULAR_METER, 0x00, mysense.humidity);

    usleep(50000);    //50-millisecond delay
  }
  return NULL;
}

//This a thread for writing to the string0.
//This process repeats forever, running in parallel with the main.
static void *handleRefreshString0(void *data)
{
  char auxCat[50] = "Humidity: %g \nTemperature: %gºC\n";
  for(;;)             //infinite loop
  {
	sprintf(auxCat,  "Humidity: %g \nTemperature: %gºC\n", mysense.humidity, mysense.temperature);
    //write to String0
    genieWriteStr(0x00, auxCat); //write to Strings0
    usleep(1000000);    //1000 milisecond delay
  }
  return NULL;
}

//This a thread for writing to the Clock
//This process repeats forever, running in parallel with the main.
static void *handleTime(void *data)
{
	time_t t;
	struct tm *ptm;
	//char *timestr;

	for(;;){
		t = time(NULL);
		//time(t);
		ptm = gmtime(&t);
		//sprintf(timestr, "%2d%02d",(ptm->tm_hour+2)%24, ptm->tm_min);
		//mtm = localtime(&t);
		//timestr = ctime(&t);
		//genieWriteObj(GENIE_OBJ_LED_DIGITS, 0x00, (timestr[11]-48)*1000+(timestr[12]-48)*100+(timestr[14]-48)*10+(timestr[15]-48));
		//genieWriteObj(GENIE_OBJ_LED_DIGITS, 0x01, (timestr[17]-48)*10+(timestr[18]-48));
		genieWriteObj(GENIE_OBJ_LED_DIGITS, 0x00, (((ptm->tm_hour+2)%24)*100)+ptm->tm_min);
		//sprintf(timestr, "%02d",ptm->tm_sec);
		genieWriteObj(GENIE_OBJ_LED_DIGITS, 0x01, ptm->tm_sec);
		usleep(1000000);    //1 second delay
	}
	return NULL;
}

//This is the event handler. Messages received from the display
//are processed here.
void handleGenieEvent(struct genieReplyStruct * reply)
{
  if(reply->cmd == GENIE_REPORT_EVENT)    //check if the cmd byte is a report event
  {
	if(reply->object == GENIE_OBJ_TRACKBAR){ //check if the object byte is that of alarm
		if(reply->index == 0)		  //check if the index byte is that of Temperature
		  alarmTemp = reply->data;
		if(reply->index == 1)		  //check if the index byte is that of humidity
		  alarmHum = reply->data;
	}
  }
  //if the received message is not a report event, print a message on the terminal window
  else
    printf("Unhandled event: command: %2d, object: %2d, index: %d, data: %d \r\n", reply->cmd, reply->object, reply->index, reply->data);
}

int main()
{
	pthread_t threadMeters;          //declare a thread for Meters
	pthread_t threadRefresh;         //declare a thread for Refresh
	pthread_t threadTime;            //declare a thread for Time
	struct genieReplyStruct reply ;  //declare a genieReplyStruct type structure

	initAM2320();

  //print some information on the terminal window
  printf("\n\n");
  printf("Raspberry-Pi Termometer\n");
  printf("==================================\n");
  printf("Program is running. Press Ctrl + C to close.\n");

  //open the Raspberry Pi's onboard serial port, baud rate is 115200
  genieSetup("/dev/ttyAMA0", 19200);
  genieWriteStr(0x00, "Termometer ON"); //write to Strings0

  //start the thread captures sensed information and puts it in the screen
  (void) pthread_create (&threadMeters,  NULL, handleSenseAndMeters, NULL);
   //start the thread for writing to the Clock
  (void) pthread_create (&threadTime,  NULL, handleTime, NULL);
   //start the thread for writing to the string0
  (void) pthread_create (&threadRefresh,  NULL, handleRefreshString0, NULL);


  for(;;)                         //infinite loop
  {
    while(genieReplyAvail())      //check if a message is available
    {
      genieGetReply(&reply);      //take out a message from the events buffer
      handleGenieEvent(&reply);   //call the event handler to process the message
    }
    usleep(50000);                //10-millisecond delay.Don't hog the
  }	                          //CPU in case anything else is happening
  return 0;
}

